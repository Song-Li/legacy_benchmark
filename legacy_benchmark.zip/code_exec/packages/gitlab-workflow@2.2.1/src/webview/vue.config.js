module.exports = {
  filenameHashing: false,
};
