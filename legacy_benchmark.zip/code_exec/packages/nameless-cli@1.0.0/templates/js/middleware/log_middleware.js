var middleware = exports = module.exports = {};

middleware.logTeam = function (request, response, done) {
    console.log('Team Function');
    done();
};

middleware.logUser = function (request, response, done) {
    console.log('User Function');
    done();
};