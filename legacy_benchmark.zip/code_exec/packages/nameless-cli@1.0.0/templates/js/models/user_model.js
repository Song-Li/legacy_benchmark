var model = exports = module.exports = {};
model.__proto = {};

model.userId = {
    type: 'INT(11)',
    notNull: true,
    autoIncrement: true,
    key: true
};

model.name = 'VARCHAR(45)';

model.pass = {
    type: 'VARCHAR(45)',
    default: 'Hallo'
};

model.pass_setter = function(pass)
{
    return passwordCrypt(pass);
};

model.__proto.comparePass = function(pass)
{
	return passwordCrypt(pass) === this.pass;
};

function passwordCrypt(pass)
{
    return pass.toUpperCase() + '123';
}