var model = exports = module.exports = {};
model.__proto = {};

model.teamId = {
    type: 'INT(11)',
    notNull: true,
    autoIncrement: true,
    key: true
};

model.member = {
	type: ['user'],
	onThisDelete: 'CASCADE', //RESTRICT | CASCADE | SET NULL | NO ACTION
	onThisUpdate: 'RESTRICT', //RESTRICT | CASCADE | SET NULL | NO ACTION
	onRemoveDelete: true
};
