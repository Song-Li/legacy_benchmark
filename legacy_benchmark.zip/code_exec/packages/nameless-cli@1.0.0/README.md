nameless-cli (beta) -- Global nameless manager
==============================================

Install
----------------------------------------------


```
npm install -g nameless
```

What is nameless-cli?
-----------------------------------------------
nameless-cli is a terminal based tool to manage and initialise a nameless project. You need nameless-cli to migrate your Models to a MySQL Database.

nameless init
-----------------------------------------------
Set up your project
nameless manage
-----------------------------------------------
A Easy way to manage Your Controllers, middleware and models.
nameless migrate
-----------------------------------------------
Migrates your models to a MySQL Database 
