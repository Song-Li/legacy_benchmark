app.controller('MetricsController',['$rootScope','$scope','$http',function($rootScope,$scope,$http){

}]);