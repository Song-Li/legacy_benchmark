app.controller('StatusController',['$rootScope','$scope','$http',function($rootScope,$scope,$http){

}]);