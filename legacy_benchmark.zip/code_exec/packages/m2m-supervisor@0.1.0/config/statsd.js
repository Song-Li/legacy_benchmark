{
    backends: [ process.cwd() + '/lib/statsd-backend' ]
}
