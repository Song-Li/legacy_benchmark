var findVar = 'uh', findVarFunc = function () {};
function findFunc () {
}

findGlobal = {s:'xd'};

(function doesNotMatter() {
    console.log('doesn\'t matter');
});
