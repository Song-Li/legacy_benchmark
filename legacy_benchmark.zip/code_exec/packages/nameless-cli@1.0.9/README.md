nameless-cli (beta) -- Global nameless manager
==============================================

Install
----------------------------------------------


```
npm install -g nameless-cli
```

What is nameless-cli?
-----------------------------------------------
nameless-cli is a terminal based tool to manage and initialise a nameless project. You need nameless-cli to migrate your Models to a MySQL Database and backup them. It contains also a testing tool (in this version just for controller).

## nameless init
-----------------------------------------------
Set up your project

## nameless manage
-----------------------------------------------
A Easy way to manage your controllers, middleware and models.

## nameless migrate
-----------------------------------------------
Migrates your models to a MySQL Database 
