var controller = exports = module.exports = {};

controller.index = function (request, response, done) {
    var modelList = this.getModel('team').find();
    response.locals.teams = modelList;

    done(null);
};

controller.login = function (request, response, done) {
    var model = this.model.find(
        {
            name: request.params.name
        })[0];

    if (model && model.comparePass(request.params.pass)) {
        response.redirect = '/user/home/' + model.getId();
    }
    else {
        response.redirect = '/';
    }

    done(null);
};

controller.logout = function (request, response, done) {
    response.redirect = '/';
    done(null);
};

controller.get = function (request, response, done) {
    response.locals.user = this.model.findById(request.urlParams.id);
    done();

};

controller.create = function (request, response, done) {
    var res = this.model.new(request.params);
    this.getModel('team').findById(request.params.team).addMember(res);
    done();
};