var controller = exports = module.exports = {};

controller.create = function (request, response, done) {
    this.model.new();
    done(null);
};