/** Test-environment-friendly function which fetches the current system locale. */
export declare function currentLocale(): string;
