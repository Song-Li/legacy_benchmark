/**
 * Busily wait for a promise to return with a maximum timeout. This should only be used if you KNOW you are not on the
 * main application thread.
 */
export declare function busyAwait<T>(promise: Promise<T>, timeoutMs: number): T | undefined;
/** Wait for a given predicate (querying at the given interval). */
export declare function waitFor(interval: number, predicate: () => boolean, cancel: () => boolean): Promise<boolean>;
