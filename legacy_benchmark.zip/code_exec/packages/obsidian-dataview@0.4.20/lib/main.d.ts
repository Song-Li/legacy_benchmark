import { Plugin, MarkdownPostProcessorContext, Component } from "obsidian";
import { FullIndex } from "data/index";
import { DataviewApi } from "api/plugin-api";
import { DataviewSettings } from "settings";
export default class DataviewPlugin extends Plugin {
    /** Plugin-wide default settigns. */
    settings: DataviewSettings;
    /** The index that stores all dataview data. */
    index: FullIndex;
    /** External-facing plugin API. */
    api: DataviewApi;
    onload(): Promise<void>;
    onunload(): void;
    registerPriorityMarkdownPostProcessor(priority: number, processor: (el: HTMLElement, ctx: MarkdownPostProcessorContext) => Promise<void>): void;
    /**
     * Utility function for registering high priority codeblocks which run before any other post processing, such as
     * emoji-twitter.
     */
    registerHighPriorityCodeblockProcessor(language: string, processor: (source: string, el: HTMLElement, ctx: MarkdownPostProcessorContext) => Promise<void>): void;
    /**
     * Based on the source, generate a dataview view. This works by doing an initial parsing pass, and then adding
     * a long-lived view object to the given component for life-cycle management.
     */
    dataview(source: string, el: HTMLElement, component: Component | MarkdownPostProcessorContext, sourcePath: string): Promise<void>;
    /** Generate a DataviewJS view running the given source in the given element. */
    dataviewjs(source: string, el: HTMLElement, component: Component | MarkdownPostProcessorContext, sourcePath: string): Promise<void>;
    /** Render all dataview inline expressions in the given element. */
    dataviewInline(el: HTMLElement, component: Component | MarkdownPostProcessorContext, sourcePath: string): Promise<void>;
    /** Update plugin settings. */
    updateSettings(settings: Partial<DataviewSettings>): Promise<void>;
    /** Call the given callback when the dataview API has initialized. */
    withApi(callback: (api: DataviewApi) => void): void;
}
