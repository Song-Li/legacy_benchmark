export interface QuerySettings {
    /** What to render 'null' as in tables. Defaults to '-'. */
    renderNullAs: string;
    /** Where to render task links - the start of the task or the end. **/
    taskLinkLocation: "start" | "end" | "none";
    /** How to render task links. If empty, will not render task links. */
    taskLinkText: string;
    /** If enabled, tasks in Dataview views will automatically have their completion date appended when they are checked. */
    taskCompletionTracking: boolean;
    /** The name of the inline field to be added as a task's completion when checked */
    taskCompletionText: string;
    /** If true, render a modal which shows no results were returned. */
    warnOnEmptyResult: boolean;
    /** The interval that views are refreshed, by default. */
    refreshInterval: number;
    /** The default format that dates are rendered in (using luxon's moment-like formatting). */
    defaultDateFormat: string;
    /** The default format that date-times are rendered in (using luxons moment-like formatting). */
    defaultDateTimeFormat: string;
    /** Maximum depth that objects will be expanded when being rendered recursively. */
    maxRecursiveRenderDepth: number;
    /** The name of the default ID field ('File'). */
    tableIdColumnName: string;
    /** The name of default ID fields on grouped data ('Group'). */
    tableGroupColumnName: string;
}
export declare const DEFAULT_QUERY_SETTINGS: QuerySettings;
export interface DataviewSettings extends QuerySettings {
    /** The prefix for inline queries by default. */
    inlineQueryPrefix: string;
    /** The prefix for inline JS queries by default. */
    inlineJsQueryPrefix: string;
    /** Enable or disable executing DataviewJS queries. */
    enableDataviewJs: boolean;
    /** Enable or disable executing inline DataviewJS queries. */
    enableInlineDataviewJs: boolean;
    /** Enable or disable rendering inline fields prettily. */
    prettyRenderInlineFields: boolean;
    /** A monotonically increasing version which tracks what schema we are on, used for migrations. */
    schemaVersion: number;
}
/** Default settings for dataview on install. */
export declare const DEFAULT_SETTINGS: DataviewSettings;
