import { DateTime, Duration } from "luxon";
import { Component } from "obsidian";
import { QuerySettings } from "settings";
import { LiteralValue } from "data/value";
/** Make an Obsidian-friendly internal link. */
export declare function createAnchor(text: string, target: string, internal: boolean): HTMLAnchorElement;
/** Render simple fields compactly, removing wrapping content like paragraph and span. */
export declare function renderCompactMarkdown(markdown: string, container: HTMLElement, sourcePath: string, component: Component): Promise<void>;
/** Create a list inside the given container, with the given data. */
export declare function renderList(container: HTMLElement, elements: LiteralValue[], component: Component, originFile: string, settings: QuerySettings): Promise<void>;
/** Create a table inside the given container, with the given data. */
export declare function renderTable(container: HTMLElement, headers: string[], values: LiteralValue[][], component: Component, originFile: string, settings: QuerySettings): Promise<void>;
/** Render a pre block with an error in it; returns the element to allow for dynamic updating. */
export declare function renderErrorPre(container: HTMLElement, error: string): HTMLElement;
/** Render a span block with an error in it; returns the element to allow for dynamic updating. */
export declare function renderErrorSpan(container: HTMLElement, error: string): HTMLElement;
/** Render a DateTime in a minimal format to save space. */
export declare function renderMinimalDate(time: DateTime, settings: QuerySettings): string;
/** Render a duration in a minimal format to save space. */
export declare function renderMinimalDuration(dur: Duration): string;
export declare type ValueRenderContext = "root" | "list";
/** Prettily render a value into a container with the given settings. */
export declare function renderValue(field: LiteralValue, container: HTMLElement, originFile: string, component: Component, settings: QuerySettings, expandList?: boolean, context?: ValueRenderContext, depth?: number): Promise<void>;
