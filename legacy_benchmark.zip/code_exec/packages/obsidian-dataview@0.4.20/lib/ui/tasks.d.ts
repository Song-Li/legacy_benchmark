import { Vault, Component } from "obsidian";
import { Grouping, Task } from "data/value";
import { QuerySettings } from "settings";
/**
 * Render a task grouping (indenting nested groupings for clarity). This will automatically bind the tasks to be checkable,
 * which requires access to a vault.
 */
export declare function renderTasks(container: HTMLElement, tasks: Grouping<Task[]>, originFile: string, component: Component, vault: Vault, settings: QuerySettings): Promise<void>;
/** Render a list of tasks as a single list. */
export declare function renderTaskList(container: HTMLElement, tasks: Task[], component: Component, vault: Vault, settings: QuerySettings): Promise<void>;
/** Check a task in a file by rewriting it. */
export declare function setTaskCheckedInFile(vault: Vault, path: string, taskLine: number, taskText: string, wasChecked: boolean, check: boolean, completionKey?: string): Promise<void>;
