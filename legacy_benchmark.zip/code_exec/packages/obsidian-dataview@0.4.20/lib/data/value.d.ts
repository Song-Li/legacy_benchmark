import { DateTime, Duration } from "luxon";
import { QuerySettings } from "settings";
/** A specific task. */
export declare class Task {
    /** The text of this task. */
    text: string;
    /** The line this task shows up on. */
    line: number;
    /** The full path of the file this task is in. */
    path: string;
    /** Whether or not this task was completed. */
    completed: boolean;
    /** Whether or not this task and all of it's subtasks are completed. */
    fullyCompleted: boolean;
    /** If true, this is a real task; otherwise, it is a list element above/below a task. */
    real: boolean;
    /** Any subtasks of this task. */
    subtasks: Task[];
    /** A link which points to this task, or to the closest block that this task is contained in. */
    link: Link;
    /** A link which points to the section that this task is a part of. */
    section: Link;
    /** Additional metadata like inline annotations */
    annotations?: Record<string, LiteralValue>;
    /** Special annotation for when this task was created. */
    created?: DateTime;
    /** Special annotation for when this task was due. */
    due?: DateTime;
    /** Special annotation for when this task was completed. */
    completion?: DateTime;
    /** Create a task from a record. */
    static fromObject(obj: Record<string, LiteralValue>): Task;
    constructor(init?: Partial<Task>);
    id(): string;
    markdown(): string;
    /** Return a new task where the created and completed fields are assigned to the given defaults if not present. */
    withDefaultDates(defaultCreated?: DateTime, defaultCompleted?: DateTime): Task;
    toObject(inlineAnnotations?: boolean): Record<string, LiteralValue>;
}
/** An Obsidian link with all associated metadata. */
export declare class Link {
    /** The file path this link points to. */
    path: string;
    /** The display name associated with the link. */
    display?: string;
    /** The block ID or header this link points to within a file, if relevant. */
    subpath?: string;
    /** Is this link an embedded link (!)? */
    embed: boolean;
    /** The type of this link, which determines what 'subpath' refers to, if anything. */
    type: "file" | "header" | "block";
    static file(path: string, embed?: boolean, display?: string): Link;
    static header(path: string, header: string, embed?: boolean, display?: string): Link;
    static block(path: string, blockId: string, embed?: boolean, display?: string): Link;
    static fromObject(object: Record<string, any>): Link;
    private constructor();
    /** Checks for link equality (i.e., that the links are pointing to the same exact location). */
    equals(other: Link): boolean;
    toString(): string;
    /** Convert this link to a raw object which */
    toObject(): Record<string, any>;
    /** Return a new link which points to the same location but with a new display value. */
    withDisplay(display?: string): Link;
    /** Convert a file link into a link to a specific header. */
    withHeader(header: string): Link;
    /** Convert any link into a link to its file. */
    toFile(): Link;
    /** Convert this link into an embedded link. */
    toEmbed(): Link;
    /** Convert this link to markdown so it can be rendered. */
    markdown(): string;
    /** The stripped name of the file this link points into. */
    fileName(): string;
}
/** Shorthand for a mapping from keys to values. */
export declare type DataObject = {
    [key: string]: LiteralValue;
};
/** The literal types supported by the query engine. */
export declare type LiteralType = "boolean" | "number" | "string" | "date" | "duration" | "link" | "task" | "array" | "object" | "html" | "function" | "null";
/** The raw values that a literal can take on. */
export declare type LiteralValue = boolean | number | string | DateTime | Duration | Link | Task | Array<LiteralValue> | DataObject | HTMLElement | Function | null;
/** A grouping on a type which supports recursively-nested groups. */
export declare type Grouping<T> = {
    type: "base";
    value: T;
} | {
    type: "grouped";
    groups: {
        key: LiteralValue;
        value: Grouping<T>;
    }[];
};
/** Maps the string type to it's external, API-facing representation. */
export declare type LiteralRepr<T extends LiteralType> = T extends "boolean" ? boolean : T extends "number" ? number : T extends "string" ? string : T extends "duration" ? Duration : T extends "date" ? DateTime : T extends "null" ? null : T extends "link" ? Link : T extends "task" ? Task : T extends "array" ? Array<LiteralValue> : T extends "object" ? Record<string, LiteralValue> : T extends "html" ? HTMLElement : T extends "function" ? Function : any;
/** A wrapped literal value which can be switched on. */
export declare type WrappedLiteralValue = LiteralValueWrapper<"string"> | LiteralValueWrapper<"number"> | LiteralValueWrapper<"boolean"> | LiteralValueWrapper<"date"> | LiteralValueWrapper<"duration"> | LiteralValueWrapper<"link"> | LiteralValueWrapper<"task"> | LiteralValueWrapper<"array"> | LiteralValueWrapper<"object"> | LiteralValueWrapper<"html"> | LiteralValueWrapper<"function"> | LiteralValueWrapper<"null">;
export interface LiteralValueWrapper<T extends LiteralType> {
    type: T;
    value: LiteralRepr<T>;
}
export declare namespace Values {
    /** Convert an arbitary value into a reasonable, Markdown-friendly string if possible. */
    function toString(field: any, setting?: QuerySettings, recursive?: boolean): string;
    /** Wrap a literal value so you can switch on it easily. */
    function wrapValue(val: LiteralValue): WrappedLiteralValue | undefined;
    /** Compare two arbitrary JavaScript values. Produces a total ordering over ANY possible dataview value. */
    function compareValue(val1: LiteralValue, val2: LiteralValue, linkNormalizer?: (link: string) => string): number;
    /** Find the corresponding Dataveiw type for an arbitrary value. */
    function typeOf(val: any): LiteralType | undefined;
    /** Determine if the given value is "truthy" (i.e., is non-null and has data in it). */
    function isTruthy(field: LiteralValue): boolean;
    /** Deep copy a field. */
    function deepCopy<T extends LiteralValue>(field: T): T;
    function isString(val: any): val is string;
    function isNumber(val: any): val is number;
    function isDate(val: any): val is DateTime;
    function isDuration(val: any): val is Duration;
    function isNull(val: any): val is null | undefined;
    function isArray(val: any): val is any[];
    function isBoolean(val: any): val is boolean;
    function isLink(val: any): val is Link;
    function isTask(val: any): val is Task;
    function isHtml(val: any): val is HTMLElement;
    function isObject(val: any): val is Record<string, any>;
    function isFunction(val: any): val is Function;
}
export declare namespace Groupings {
    function base<T>(value: T): Grouping<T>;
    function grouped<T>(values: {
        key: LiteralValue;
        value: Grouping<T>;
    }[]): Grouping<T>;
}
