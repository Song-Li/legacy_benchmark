import { MetadataCache, TFile } from "obsidian";
import { DateTime } from "luxon";
import { FullIndex } from "data/index";
import { Link, LiteralValue, Task } from "./value";
/** All extracted markdown file metadata obtained from a file. */
export declare class PageMetadata {
    /** The path this file exists at. */
    path: string;
    /** Obsidian-provided date this page was created. */
    ctime: DateTime;
    /** Obsidian-provided date this page was modified. */
    mtime: DateTime;
    /** Obsidian-provided size of this page in bytes. */
    size: number;
    /** The day associated with this page, if relevant. */
    day?: DateTime;
    /** The first H1/H2 header in the file. May not exist. */
    title?: string;
    /** All of the fields contained in this markdown file - both frontmatter AND in-file links. */
    fields: Map<string, LiteralValue>;
    /** All of the exact tags (prefixed with '#') in this file overall. */
    tags: Set<string>;
    /** All of the aliases defined for this file. */
    aliases: Set<string>;
    /** All OUTGOING links (including embeds, header + block links) in this file. */
    links: Link[];
    /** All tasks contained within this file. */
    tasks: Task[];
    constructor(path: string, init?: Partial<PageMetadata>);
    /** Parse all subtags out of the given tag. I.e., #hello/i/am would yield [#hello/i/am, #hello/i, #hello]. */
    static parseSubtags(tag: string): string[];
    /** The name (based on path) of this file. */
    name(): string;
    /** The containing folder (based on path) of this file. */
    folder(): string;
    /** The extension of this file (likely 'md'). */
    extension(): string;
    /** Return a set of tags AND all of their parent tags (so #hello/yes would become #hello, #hello/yes). */
    fullTags(): Set<string>;
    /** Convert all links in this file to file links. */
    fileLinks(): Link[];
    /** Map this metadata to a full object; uses the index for additional data lookups.  */
    toObject(index: FullIndex): Record<string, LiteralValue>;
}
/**
 * Partial metadata object which contains all the information extracted from raw markdown. This is combined with the
 * metadata cache to generate the final PageMetadata object.
 */
export interface ParsedMarkdown {
    tasks: Task[];
    fields: Map<string, LiteralValue[]>;
}
/** Recursively convert frontmatter into fields. We have to dance around YAML structure. */
export declare function parseFrontmatter(value: any): LiteralValue;
/** Parse a textual inline field value into something we can work with. */
export declare function parseInlineField(value: string): LiteralValue;
export declare function parseTaskForAnnotations(line: string): Record<string, LiteralValue>;
/** Add an inline field to a nexisting field array, converting a single value into an array if it is present multiple times. */
export declare function addInlineField(fields: Map<string, LiteralValue>, name: string, value: LiteralValue): void;
/** Matches lines of the form "- [ ] <task thing>". */
export declare const TASK_REGEX: RegExp;
/** Return true if the given predicate is true for the task or any subtasks. */
export declare function taskAny(t: Task, f: (t: Task) => boolean): boolean;
export declare function alast<T>(arr: Array<T>): T | undefined;
export declare const CREATED_DATE_REGEX: RegExp;
export declare const DUE_DATE_REGEX: RegExp;
export declare const DONE_DATE_REGEX: RegExp;
/**
 * A hacky approach to scanning for all tasks using regex. Does not support multiline
 * tasks yet (though can probably be retro-fitted to do so).
 */
export declare function findTasksInFile(path: string, file: string): Task[];
export declare function parseMarkdown(path: string, contents: string, inlineRegex: RegExp): ParsedMarkdown;
/** Extract markdown metadata from the given Obsidian markdown file. */
export declare function parsePage(file: TFile, cache: MetadataCache, markdownData: ParsedMarkdown): PageMetadata;
