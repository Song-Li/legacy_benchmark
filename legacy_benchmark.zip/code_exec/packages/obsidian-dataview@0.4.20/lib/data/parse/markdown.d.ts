/** Importer for markdown documents. */
import { PageMetadata } from "data/metadata";
import { LiteralValue, Task } from "data/value";
import { CachedMetadata, HeadingCache, MetadataCache, TFile } from "obsidian";
export interface ParsedMarkdown {
    fields: Map<string, LiteralValue[]>;
    tasks: Task[];
}
/** Recursively convert frontmatter into fields. We have to dance around YAML structure. */
export declare function parseFrontmatter(value: any): LiteralValue;
/** Add an inline field to a nexisting field array, converting a single value into an array if it is present multiple times. */
export declare function addInlineField(fields: Map<string, LiteralValue>, name: string, value: LiteralValue): void;
/** Matches lines of the form "- [ ] <task thing>". */
export declare const TASK_REGEX: RegExp;
/** Matches Obsidian block IDs, which are at the end of the line of the form ^blockid. */
export declare const TASK_BLOCK_REGEX: RegExp;
/** Return true if the given predicate is true for the task or any subtasks. */
export declare function taskAny(t: Task, f: (t: Task) => boolean): boolean;
export declare function alast<T>(arr: Array<T>): T | undefined;
/** Find the header that is most immediately above the given line number. */
export declare function findPreviousHeader(line: number, headers: HeadingCache[]): string | undefined;
/**
 * A hacky approach to scanning for all tasks using regex. Does not support multiline
 * tasks yet (though can probably be retro-fitted to do so).
 */
export declare function findTasksInFile(path: string, file: string, metadata: CachedMetadata): Task[];
export declare function parseMarkdown(path: string, metadata: CachedMetadata, contents: string, inlineRegex: RegExp): ParsedMarkdown;
/** Extract markdown metadata from the given Obsidian markdown file. */
export declare function parsePage(file: TFile, cache: MetadataCache, markdownData: ParsedMarkdown): PageMetadata;
