/** Stores various indices on all files in the vault to make dataview generation fast. */
import { Result } from "api/result";
import { DataObject } from "data/value";
import { MetadataCache, TAbstractFile, TFile, Vault } from "obsidian";
import { PageMetadata } from "data/metadata";
import { DateTime } from "luxon";
import { FileImporter } from "data/import/import-manager";
/** A generic index which indexes variables of the form key -> value[], allowing both forward and reverse lookups. */
export declare class IndexMap {
    /** Maps key -> values for that key. */
    map: Map<string, Set<string>>;
    /** Cached inverse map; maps value -> keys that reference that value. */
    invMap: Map<string, Set<string>>;
    /** Create a new, empty index map. */
    constructor();
    /** Returns all values for the given key. */
    get(key: string): Set<string>;
    /** Returns all keys that reference the given key. */
    getInverse(value: string): Set<string>;
    set(key: string, values: Set<string>): IndexMap;
    /** Clears all values for the given key so they can be re-added. */
    delete(key: string): boolean;
    /** Rename all references to the given key to a new value. */
    rename(oldKey: string, newKey: string): boolean;
    /** Clear the entire index. */
    clear(): void;
}
/** Lists all possible index events. */
export interface IndexEvents {
    /** Called when dataview metadata for a file changes. */
    trigger(evt: "dataview:metadata-change", type: "rename", file: TAbstractFile, oldPath: string): void;
    /** Called when a file is deleted from the dataview index. */
    trigger(evt: "dataview:metadata-change", type: "update" | "delete", file: TAbstractFile): void;
}
/** Aggregate index which has several sub-indices and will initialize all of them. */
export declare class FullIndex {
    vault: Vault;
    metadataCache: MetadataCache;
    events: IndexEvents;
    /** Generate a full index from the given vault. */
    static create(vault: Vault, metadata: MetadataCache, events: IndexEvents): FullIndex;
    pages: Map<string, PageMetadata>;
    /** Map files -> tags in that file, and tags -> files. This version includes subtags. */
    tags: IndexMap;
    /** Map files -> exact tags in that file, and tags -> files. This version does not automatically add subtags. */
    etags: IndexMap;
    /** Map files -> linked files in that file, and linked file -> files that link to it. */
    links: IndexMap;
    /** Map exact folder paths to files; the 'exact' version of 'prefix'. */
    folders: IndexMap;
    /** Search files by path prefix. */
    prefix: PrefixIndex;
    /** Caches rows of CSV files. */
    csv: CsvCache;
    /**
     * The current "revision" of the index, which monotonically increases for every index change. Use this to determine
     * if you are up to date.
     */
    revision: number;
    /** Asynchronously parses files in the background using web workers. */
    importer: FileImporter;
    /** Construct a new index over the given vault and metadata cache. */
    private constructor();
    /** Runs through the whole vault to set up initial file */
    initialize(): void;
    /** Queue a file for reloading; this is done asynchronously in the background and may take a few seconds. */
    reload(file: TFile): void;
    /** "Touch" the index, incrementing the revision number and causing downstream views to reload. */
    touch(): void;
    private reloadInternal;
}
/** A node in the prefix tree. */
export declare class PrefixIndexNode {
    files: Set<string>;
    element: string;
    totalCount: number;
    children: Map<string, PrefixIndexNode>;
    constructor(element: string);
    static add(root: PrefixIndexNode, path: string): void;
    static remove(root: PrefixIndexNode, path: string): void;
    static find(root: PrefixIndexNode, prefix: string): PrefixIndexNode | null;
    /** Gather all files at and under the given node, optionally filtering the result by the given filter. */
    static gather(root: PrefixIndexNode, filter?: (path: string) => boolean): Set<string>;
    static gatherRec(root: PrefixIndexNode, output: Set<string>): void;
}
/** Indexes files by their full prefix - essentially a simple prefix tree. */
export declare class PrefixIndex {
    vault: Vault;
    updateRevision: () => void;
    static create(vault: Vault, updateRevision: () => void): PrefixIndex;
    private root;
    constructor(vault: Vault, updateRevision: () => void);
    /** Run through the whole vault to set up the initial prefix index. */
    initialize(): void;
    /** Get the list of all files under the given path. */
    get(prefix: string, filter?: (path: string) => boolean): Set<string>;
    /** Determines if the given path exists in the prefix index. */
    pathExists(path: string): boolean;
    /** Determines if the given prefix exists in the prefix index. */
    nodeExists(prefix: string): boolean;
    /**
     * Use the in-memory prefix index to convert a relative path to an absolute one.
     */
    resolveRelative(path: string, origin?: string): string;
}
/** Simple path filters which filter file types. */
export declare namespace PathFilters {
    function csv(path: string): boolean;
    function markdown(path: string): boolean;
}
/**
 * Caches in-use CSVs to make high-frequency reloads (such as actively looking at a document
 * that uses CSV) fast.
 */
export declare class CsvCache {
    vault: Vault;
    static CACHE_EXPIRY_SECONDS: number;
    cache: Map<string, {
        data: DataObject[];
        loadTime: DateTime;
    }>;
    cacheClearInterval: number;
    constructor(vault: Vault);
    /** Load a CSV file from the cache, doing a fresh load if it has not been loaded. */
    get(path: string): Promise<Result<DataObject[], string>>;
    /** Do the actual raw loading of a CSV path (which is either local or an HTTP request). */
    private load;
    /** Clear old entries in the cache (as measured by insertion time). */
    private clearOldEntries;
}
