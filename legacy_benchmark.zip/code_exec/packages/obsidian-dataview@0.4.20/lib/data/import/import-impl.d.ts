/** Actual raw implementation for the background importer. Mainly handles message passing. */
import { ParsedMarkdown } from "data/parse/markdown";
import { CachedMetadata } from "obsidian";
export declare function runImport(path: string, contents: string, metadata: CachedMetadata): ParsedMarkdown;
