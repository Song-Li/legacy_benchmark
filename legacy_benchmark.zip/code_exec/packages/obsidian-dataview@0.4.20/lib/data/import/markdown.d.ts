/** Importer for markdown documents. */
import { PageMetadata } from "data/metadata";
import { LiteralValue, Task } from "data/value";
import { MetadataCache, TFile } from "obsidian";
export interface ParsedMarkdown {
    fields: Map<string, LiteralValue[]>;
    tasks: Task[];
}
/** Recursively convert frontmatter into fields. We have to dance around YAML structure. */
export declare function parseFrontmatter(value: any): LiteralValue;
/** Add an inline field to a nexisting field array, converting a single value into an array if it is present multiple times. */
export declare function addInlineField(fields: Map<string, LiteralValue>, name: string, value: LiteralValue): void;
/** Matches lines of the form "- [ ] <task thing>". */
export declare const TASK_REGEX: RegExp;
/** Return true if the given predicate is true for the task or any subtasks. */
export declare function taskAny(t: Task, f: (t: Task) => boolean): boolean;
export declare function alast<T>(arr: Array<T>): T | undefined;
/**
 * A hacky approach to scanning for all tasks using regex. Does not support multiline
 * tasks yet (though can probably be retro-fitted to do so).
 */
export declare function findTasksInFile(path: string, file: string): Task[];
export declare function parseMarkdown(path: string, contents: string, inlineRegex: RegExp): ParsedMarkdown;
/** Extract markdown metadata from the given Obsidian markdown file. */
export declare function parsePage(file: TFile, cache: MetadataCache, markdownData: ParsedMarkdown): PageMetadata;
