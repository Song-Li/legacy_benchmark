/** Entry-point script used by the index as a web worker. */
export {};
