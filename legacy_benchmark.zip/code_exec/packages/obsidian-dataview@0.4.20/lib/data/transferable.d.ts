/** An encoded type which can be transfered across threads. */
export declare type TransferableValue = null | undefined | number | string | boolean | Array<TransferableValue> | Record<string, any> | Map<string, TransferableValue> | Set<TransferableValue> | {
    "___transfer-type": "date" | "duration" | "link" | "task";
    value: Record<string, TransferableValue>;
    options?: Record<string, TransferableValue>;
};
export declare namespace Transferable {
    /** Convert a literal value to a serializer-friendly transferable value. Does not work for all types. */
    function transferable(value: any): TransferableValue;
    /** Convert a transferable value back to a literal value we can work with. */
    function value(transferable: TransferableValue): any;
}
