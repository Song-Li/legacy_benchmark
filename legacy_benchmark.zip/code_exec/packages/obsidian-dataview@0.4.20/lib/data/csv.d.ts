import { DataObject } from "./value";
/** Parse a CSV file into a collection of data rows. */
export declare function parseCsv(content: string): DataObject[];
