import { DateTime } from "luxon";
import type { FullIndex } from "data/index";
import { Link, LiteralValue, Task } from "data/value";
/** All extracted markdown file metadata obtained from a file. */
export declare class PageMetadata {
    /** The path this file exists at. */
    path: string;
    /** Obsidian-provided date this page was created. */
    ctime: DateTime;
    /** Obsidian-provided date this page was modified. */
    mtime: DateTime;
    /** Obsidian-provided size of this page in bytes. */
    size: number;
    /** The day associated with this page, if relevant. */
    day?: DateTime;
    /** The first H1/H2 header in the file. May not exist. */
    title?: string;
    /** All of the fields contained in this markdown file - both frontmatter AND in-file links. */
    fields: Map<string, LiteralValue>;
    /** All of the exact tags (prefixed with '#') in this file overall. */
    tags: Set<string>;
    /** All of the aliases defined for this file. */
    aliases: Set<string>;
    /** All OUTGOING links (including embeds, header + block links) in this file. */
    links: Link[];
    /** All tasks contained within this file. */
    tasks: Task[];
    constructor(path: string, init?: Partial<PageMetadata>);
    /** Parse all subtags out of the given tag. I.e., #hello/i/am would yield [#hello/i/am, #hello/i, #hello]. */
    static parseSubtags(tag: string): string[];
    /** The name (based on path) of this file. */
    name(): string;
    /** The containing folder (based on path) of this file. */
    folder(): string;
    /** The extension of this file (likely 'md'). */
    extension(): string;
    /** Return a set of tags AND all of their parent tags (so #hello/yes would become #hello, #hello/yes). */
    fullTags(): Set<string>;
    /** Convert all links in this file to file links. */
    fileLinks(): Link[];
    /** Map this metadata to a full object; uses the index for additional data lookups.  */
    toObject(index: FullIndex): Record<string, LiteralValue>;
}
