const path = require('path');

module.exports = path.join(__dirname, 'bin', 'exiftool');
